--create database SistemaInventarios
--use SistemaInventarios
/*create table Vendedor
(
	Id_Vendedor char(4) primary key,
	NombreV varchar(40),
	HorarioV time
)*/
--alter table Vendedor drop column HorarioV
--delete from Vendedor where Id_Vendedor='Vdd1'
/*go
Create proc EntradaVendedor(@Id_Vendedor char(4), @NombreV varchar(40))
as begin
insert into Vendedor values(@Id_Vendedor, @NombreV)
end
go*/

/*create table Cliente
(
	Id_Cliente char(4) primary key,
	Nombre varchar(40),
	
)*/
/*create table Proveedor
(
	Id_Proveedor char(4) primary key,
	NombreP varchar(40),
	TelefonoP char(15),
	HorarioP time,
	Credito float
)*/
--alter table Proveedor drop column HorarioP
/*go
Create proc EntradaProveedor(@Id_Proveedor char(4), @NombreP varchar(40), @TelefonoP char(15), @Credito float)
as begin
insert into Proveedor values(@Id_Proveedor,@NombreP, @TelefonoP , @Credito)
end
go*/
/*create table Compra
(
	Id_compra char(4) primary key,
	Id_Proveedor char (4),
	Id_Producto char(4),
	Cantidad int,
	Fecha date,
	Hora time,
	Subtotal float,
	Saldo float,
	foreign key(Id_Proveedor) references Proveedor(Id_Proveedor),
	foreign key(Id_Producto) references Producto(Id_Producto)
)*/
--alter table Compra drop column Hora
/*go
Create proc EntradaCompra(@Id_compra char(4), @Id_Proveedor char(4), @Id_Producto char(4), 
							@Cantidad int, @Subtotal float, @Saldo float)
as begin
insert into Compra values(@Id_compra, @Id_Proveedor, @Id_Producto, @Cantidad, 
							@Subtotal, @Saldo)
end
go*/
/*create table Producto
(
	Id_Producto char(4) primary key,
	NomProduc varchar(40),
	Marca varchar(40),
	Existencia int,
	PrecioV float,
	PrecioC float
)*/
/*go
Create proc EntradaProducto(@Id_Producto char(4), @NomProduc varchar(40), @Marca varchar(40),@Existencia int, @PrecioV  float, @PrecioC float)
as begin
insert into Producto values(@Id_Producto,@NomProduc ,@Marca, @Existencia,@PrecioV,@PrecioC)
end
go*/
/*create table Venta
(
	Id_Venta char(4) primary key,
	Id_Vendedor char(4),
	Id_Producto char(4),
	CantidadV int,
	FechaV date,
	HoraV time,
	SubtotalV float,
	SaldoV float,
	foreign key(Id_Vendedor) references Vendedor(Id_Vendedor),
	foreign key(Id_Producto) references Producto(Id_Producto)
)*/
--alter table Venta drop column FechaV
--alter table Clientes add Edad int
--10.Borrar el atributo Edad de la tabla Clientes
--alter table Clientes drop column Edad
/*go
Create proc EntradaVenta(@Id_Venta char(4),@Id_Vendedor char(4), @Id_Producto char(4), @CantidadV int, 
						 @SubtotalV float,@SaldoV float)
as begin
insert into Venta values(@Id_Venta,@Id_Vendedor,@Id_Producto,@CantidadV , @SubtotalV,@SaldoV)
end
go*/
--insert into Vendedor values ('Vdd1','Cesar Efrain', '08:30:00',1)
--alter table Vendedor add Tipo int
--update Clientes set Saldo=100 where NombreC='Pedro Gomez'
--update Vendedor set Tipo=1 where Id_Vendedor='Vdd1'

/*go
Create proc EntradaCliente(@Id_Cliente char(4), @Nombre char(40))
as begin
insert into Cliente values(@Id_Cliente,@Nombre)
end
go*/
--insert into Cliente values ('C001','Carlos Hern�ndez')
--select * from Vendedor
/*go
Create proc EliminarCliente(@Id_Cliente char(4))
as begin
delete from Cliente where Id_Cliente=@Id_Cliente
end
go*/
/*go
Create proc BuscarCliente(@Id_Cliente char(4))
as begin
select * from Cliente where Id_Cliente=@Id_Cliente
end
go*/
/*go
Create proc EntradaVendedor(@Id_Vendedor char(4), @NombreV varchar(40), @Tipo int)
as begin
insert into Vendedor values(@Id_Vendedor, @NombreV, @Tipo)
end
go*/
/*go
Create proc BuscarProducto(@Id_Producto char(4))
as begin
select * from Producto where Id_Producto=@Id_Producto
end
go*/
/*go
Create proc EliminarProducto(@Id_Producto char(4))
as begin
delete from Producto where Id_Producto=@Id_Producto
end
go*/
/*go
Create proc BuscarVenta(@Id_Venta char(4))
as begin
select * from Venta where Id_Venta=@Id_Venta
end
go*/
/*go
Create proc EliminarVenta(@Id_Venta char(4))
as begin
delete from Venta where Id_Venta=@Id_Venta
end
go*/
/*go
Create proc BuscarProveedor(@Id_Proveedor char(4))
as begin
select * from Proveedor where Id_Proveedor=@Id_Proveedor
end
go*/
/*go
Create proc EliminarProveedor(@Id_Proveedor char(4))
as begin
delete from Proveedor where Id_Proveedor=@Id_Proveedor
end
go*/
/*go
Create proc BuscarCompra(@Id_compra char(4))
as begin
select * from Compra where Id_compra=@Id_compra
end
go*/
/*go
Create proc EliminarCompra(@Id_Compra char(4))
as begin
delete from Compra where Id_Compra=@Id_Compra
end
go*/
/*go
Create proc BuscarVendedor(@Id_Vendedor char(4))
as begin
select * from Vendedor where Id_Vendedor=@Id_Vendedor
end
go*/
/*go
Create proc EliminarVendedor(@Id_Vendedor char(4))
as begin
delete from Vendedor where Id_Vendedor=@Id_Vendedor
end
go*/
select * from Cliente
select * from Proveedor
select * from Producto
select * from Compra
select * from Venta
select * from Vendedor